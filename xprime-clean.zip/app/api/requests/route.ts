import { NextResponse } from "next/server";
import { getSession } from "../../../lib/auth";
import { prisma } from "../../../lib/db";

export async function GET(req: Request) {
  const session = await getSession();
  if (!session?.id) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });

  try {
    const rows = await prisma.verificationRequest.findMany({
      where: { userId: session.id },
      orderBy: { createdAt: "desc" },
      take: 100,
    });

    const formattedRows = rows.map((row) => {
      let parsed: any = {};
      try { if (row.result) parsed = JSON.parse(row.result); } catch (e) {}

      return {
        id: row.id, 
        type: row.type, 
        reference: row.reference, 
        status: row.status,
        createdAt: row.createdAt.toISOString(), 
        cnic: row.reference,
        nameUrdu: parsed.nameUrdu || parsed.name || "N/A",
        dob: parsed.dob || "N/A", 
        issueDate: parsed.issueDate || "N/A",
        expiryDate: parsed.expiryDate || "N/A", 
        gender: parsed.gender || "N/A", 
        motherName: parsed.motherName || "N/A",
        placeOfBirth: parsed.placeOfBirth || "N/A", 
        address: parsed.address || "N/A", 
      };
    });

    return NextResponse.json(formattedRows);
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}